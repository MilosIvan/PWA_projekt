<?php
    function dohvat($kategorija, $limit) {
        include 'connect.php';

        $query = "SELECT * FROM vijesti WHERE arhiva = 0 AND kategorija = '$kategorija'
                ORDER BY datum DESC LIMIT $limit";
        $result = mysqli_query($dbc, $query);
        while ($row = mysqli_fetch_array($result)) {
            echo "
                <article>
                    <a href='clanak.php?id=". $row['id'] ."'>
                    <img src='img/". $row['slika'] ."' alt='slika'>
                    <h2>". $row['naslov'] ."</h2>
                    <p>". $row['sazetak'] ."</p>
                    </a>
                </article>
            ";
        }
    }
?>