<form action="forma.php?akcija=2" method="post">
    <h1 style="margin: 50px;">Brisanje vijesti</h1>

    <div class="form-item">
        <label for="selekcija">Odaberite vijest koju želite izbrisati</label>
        <div class="form-field">
            <select name="selekcija" id="">
            <?php
                include 'connect.php';
    
                $querry = "SELECT id, naslov FROM vijesti";
                $result = mysqli_query($dbc, $querry);
                if($result) {
                    while($row = mysqli_fetch_array($result)) {
                        echo '<option value="'. $row['id'] .'">'. $row['naslov'] .'</option>';
                    }
                }
            ?>
            </select>
        </div> 
    </div>

    <div class="form-item">
        <label for="selekcija">Potvrda</label>
        <div class="form-field">
            <input type="checkbox" name="potvrda">
        </div> 
    </div>

    <div class="form-item"> 
        <input type="submit" name="submit" value="Obriši" class="button" id="button">
    </div> 
</form>

<?php
    if(isset($_POST['submit']) && isset($_POST['potvrda'])) {
        $querry = "DELETE FROM vijesti WHERE id = ". $_POST['selekcija'];
        if(mysqli_query($dbc, $querry)) {
            echo "Vijest je uspješno izbrisana.";
        } else {
            echo mysqli_error($mysqli);
        }
    }
?>