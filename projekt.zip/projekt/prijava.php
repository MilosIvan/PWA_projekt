<!DOCTYPE html>
<html>
    <head>
        <title>Prijava</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/prijava&registracija.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
        <script src="js/prijava.js"></script>
    </head>

    <body>
        <?php include 'header.php'; ?>

        <main>

            <form action="prijava.php" method="post" name="prijava">
                <h1>Prijava</h1>

                <label for="username">Korisničko ime</label>
                <input type="text" name="username" id="username" required>

                <label for="password">Lozinka</label>
                <input type="password" name="password" id="password" required>

                <button type="submit" name="submit" class="button">Prijava</button>
                <a href="registracija.php" class="button">Registracija</a>
            </form>

            <?php
                if(isset($_POST['submit'])) {
                    include 'connect.php';

                    $query = "SELECT korisnicko_ime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?";

                    $stmt = mysqli_stmt_init($dbc);
                    $korisnicko_ime = $_POST['username'];
                    $lozinka = $_POST['password'];

                    if(mysqli_stmt_prepare($stmt, $query)) {
                        mysqli_stmt_bind_param($stmt, 's', $korisnicko_ime);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_store_result($stmt);
                    }

                    if(mysqli_stmt_num_rows($stmt) > 0) {
                        mysqli_stmt_bind_result($stmt, $username, $password, $razina);
                        mysqli_stmt_fetch($stmt);
                        if(password_verify($lozinka, $password)) {
                                session_start();
                                $_SESSION['korisnicko_ime'] = $username;
                                $_SESSION['razina'] = $razina;

                                if($razina == 'admin') {
                                    header("Location: forma.php?akcija=1");
                                    exit();
                                } else {
                                    echo "Korisnik ". $_SESSION['korisnicko_ime'] .": nemate pravo pristupa administratorskoj stranici!";
                                }
                        } else {
                            echo "
                                <p>Unijeli ste pogrešno korisničko ime ili lozinku</p>
                            ";
                        }
                    }
                }
            ?>

        </main>

        <?php include 'footer.php'; ?>
    </body>
</html>