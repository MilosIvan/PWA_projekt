<!DOCTYPE html>
<html>
    <head>
        <title>Prijava</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/prijava&registracija.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
        <script src="js/registracija.js"></script>
    </head>

    <body>
        <?php include 'header.php'; ?>

        <main>

            <form action="registracija.php" method="post" name="registracija">
                <h1>Registracija</h1>

                <label for="name">Ime</label>
                <input type="text" name="name" id="name" required>

                <label for="surname">Prezime</label>
                <input type="text" name="surname" id="surname" required>

                <label for="username">Korisničko ime</label>
                <input type="text" name="username" id="username" required>

                <label for="password">Lozinka</label>
                <input type="password" name="password" id="password" required>

                <label for="password1">Potvrda Lozinke</label>
                <input type="password" name="password1" id="password1" required>

                <button type="submit" name="submit" class="button">Registracija</button>
            </form>

            <?php
                if(isset($_POST['submit'])) {
                    include 'connect.php';

                    $korisnicko_ime = $_POST['username'];
                    $query1 = "SELECT * FROM korisnik WHERE korisnicko_ime = '$korisnicko_ime'";
                    $result1 = mysqli_query($dbc, $query1);

                    if(mysqli_num_rows($result1) == 0) {
                        $query = "INSERT INTO korisnik(ime, prezime, korisnicko_ime, lozinka, razina) 
                                VALUES(?, ?, ?, ?, ?)";
    
                        $stmt = mysqli_stmt_init($dbc);
        
                        $ime = $_POST['name'];
                        $prezime = $_POST['surname'];
                        $lozinka = $_POST['password'];
                        $lozinka_hashed = password_hash($lozinka, CRYPT_BLOWFISH);
                        $razina = 'user';
        
                        if(mysqli_stmt_prepare($stmt, $query)) {
                            mysqli_stmt_bind_param($stmt, 'sssss', $ime, $prezime, $korisnicko_ime, $lozinka_hashed, $razina);
                            mysqli_stmt_execute($stmt);
                        }
                    }
                    else {
                        echo 'korisnicko ime je zauzeto';
                    }
                }
            ?>

        </main>

        <?php include 'footer.php'; ?>
    </body>
</html>