<?php
    if(isset($_POST['submit'])) {
        include 'connect.php';
            
        $naslov = $_POST['title'];
        $sazetak=$_POST['about'];
        $sadrzaj=$_POST['content'];
        $slika = $_FILES['photo']['name'];
        $kategorija=$_POST['category'];
        $datum=date('Y-m-d H:i:s', strtotime('now'));
        if(isset($_POST['archive'])){
            $arhiva=1;
        }else{
            $arhiva=0;
        }
                
        $target_dir = 'img/'.$slika;
        move_uploaded_file($_FILES["photo"]["tmp_name"], $target_dir);
        $sadrzaj = str_replace("\r\n", "<br>", $sadrzaj);
                
        $query = "INSERT INTO vijesti (datum, naslov, sazetak, tekst, slika, kategorija, arhiva)
                    VALUES ('$datum', '$naslov', '$sazetak', '$sadrzaj', '$slika', '$kategorija', '$arhiva')";
                
        $result = mysqli_query($dbc, $query) or die('Error querying databese.');
        
        mysqli_close($dbc);
    }
?>