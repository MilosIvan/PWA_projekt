<header>
    <img src="img/logo.png" alt="logo" class="logo">
    <nav>
        <a href="index.php">Naslovnica</a>
        <a href="kategorija.php?kategorija=Glazba">Glazba</a>
        <a href="kategorija.php?kategorija=Sport">Sport</a>
        <?php
            if(!isset($_SESSION['korisnicko_ime'])) {
                echo '<a href="prijava.php">Admnistracija</a>';
            } else {
                echo '<a href="forma.php?akcija=1">Admnistracija</a>';
                echo '<a href="odjava.php">Odjava</a>';
            }
        ?>
    </nav>
</header>