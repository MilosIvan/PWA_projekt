<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <?php
            $kategorija = $_GET['kategorija'];
        ?>
        <title><?php echo $kategorija; ?></title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/kategorija.css">
        <?php include 'dohvat.php'; ?>
    </head>

    <body>
        <?php 
            session_start();
        ?>
        <?php include 'header.php'; ?>

        <main>
        <section class="kategorija">
                <h1><?php echo $kategorija; ?></h1>
                <hr>
                <div class="artikli">

                    <?php
                        dohvat($kategorija, 10);
                    ?>

                </div>
            </section>
        </main>

        <?php include 'footer.php'; ?>
    </body>
</html>