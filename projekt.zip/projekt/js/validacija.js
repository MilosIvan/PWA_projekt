document.getElementById("button").onclick = function (event) {
    var slanje_forme = true;

    var naslov_input = document.getElementById('naslov');
    var naslov = naslov_input.value;
    if(naslov.length < 5 || naslov.length > 30) {
        slanje_forme = false;
        naslov_input.style.border = "1.5px solid red";
        document.getElementById('span_naslov').innerHTML = "Naslov mora biti duljine 5 do 30 znakova!";
    }

    var sazetak_textarea = document.getElementById('sazetak');
    var sazetak = sazetak_textarea.value;
    if(sazetak.length < 10 || sazetak.length > 100) {
        slanje_forme = false;
        sazetak_textarea.style.border = "1.5px solid red";
        document.getElementById('span_sazetak').innerHTML = "Sažetak mora biti duljine 10 do 100 znakova!";
    }

    var sadrzaj_textarea = document.getElementById('sadrzaj');
    var sadrzaj = sadrzaj_textarea.value;
    if(sadrzaj.length == 0) {
        slanje_forme = false;
        sadrzaj_textarea.style.border = "1.5px solid red";
        document.getElementById('span_sadrzaj').innerHTML = "Unesite sadržaj";
    }

    var slika = document.getElementById('slika');
    if(slika.files.length === 0) {
        slanje_forme = false;
        document.getElementById('span_slika').innerHTML = "Odaberite sliku!"
    }

    if(slanje_forme != true) {
        event.preventDefault();
    }
}