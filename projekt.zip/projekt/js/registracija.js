$(function() {
    $("form[name='registracija']").validate({

      rules: {
        name: {
          required: true,
        },
        surname: {
            required: true
        },
        username: {
            required: true,
            minlength: 6
        },
        password: {
          required: true,
          minlength: 6,
        },
        password1:{
          required: true,
          equalTo: "#password",
        }
      },

      messages: {
        name: {
          required: "Potrebno je unijeti ime"
        },
        surname: {
            required: "Potrebno je unijeti prezime"
        },
        username: {
            required: "Potrebno je unijeti korisničko ime",
            minlength: "Korisničko ime mora imati najmanje 6 znakova",
          },
        password: {
          required: "Potrebno je unijeti lozinku",
          minlength: "Lozinka mora imati najmanje 6 znakova",
        },
        password1: {
          required: "Potrebno je ponoviti lozinku",
          equalTo: "Lozinke trebaju biti iste"
        },
     },

      submitHandler: function(form) {
        form.submit();
      }
    });
  });