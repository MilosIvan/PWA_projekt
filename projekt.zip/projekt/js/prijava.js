$(function() {
    $("form[name='prijava']").validate({

      rules: {
        username: {
            required: true,
        },
        password: {
          required: true,
        }
      },

      messages: {
        username: {
            required: "Potrebno je unijeti korisničko ime",
          },
        password: {
          required: "Potrebno je unijeti lozinku",
        }
     },

      submitHandler: function(form) {
        form.submit();
      }
    });
  });