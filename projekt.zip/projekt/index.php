<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Naslovnica</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/index.css">
        <?php include 'dohvat.php'; ?>          <!-- dohvat funkcije za citanje iz baze -->
    </head>

    <body>
        <?php 
            session_start();
        ?>
        <?php include 'header.php'; ?>          <!-- dohvat header-a -->

        <main>
            <section class="kategorija">
                <h1>Sport</h1>
                <hr>
                <div class="artikli">

                    <?php
                        dohvat('Sport', 3);     //citanje iz baze
                    ?>

                </div>
            </section>

            <section class="kategorija">
                <h1>Glazba</h1>
                <hr>
                <div class="artikli">

                    <?php
                        dohvat('Glazba', 3);    //citanje iz baze
                    ?>

                </div>
            </section>

            <?php include 'footer.php'; ?>      <!-- dohvat footer-a -->
        </main>
    </body>
</html>