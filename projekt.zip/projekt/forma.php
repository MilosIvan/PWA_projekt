<!DOCTYPE html>
<html>
    <head>
        <title>Forma</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/forma.css">
    </head>

    <body>
        <?php include 'header.php'; ?>

        <main>
            <div id="navigacija">
                <a href="forma.php?akcija=1">Nova vijest</a>
                <a href="forma.php?akcija=2">Brisanje vijest</a>
            </div>

            <?php
                if(isset($_GET['akcija'])) {
                    $akcija = $_GET['akcija'];
                    if ($akcija == 1) {
                        include 'forma_unos.html';
                        include 'unos.php';
                    }
                    else {
                        include 'forma_brisanje.php';
                    }
                } else {
                    include 'forma_unos.html';
                    include 'unos.php';
                }
            ?>

        </main>

        <script src="js/validacija.js"></script>

        <?php include 'footer.php'; ?>
    </body>
</html>