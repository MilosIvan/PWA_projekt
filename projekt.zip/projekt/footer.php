<footer>
    <p>Copyright 2019 Morgenpost Verlag GmbH</p>
</footer>