<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <?php
            include 'connect.php';

            $query = "SELECT * FROM vijesti WHERE id = ". $_GET['id'];
            $result = mysqli_query($dbc, $query);
            if(isset($result)) {
                $row = mysqli_fetch_array($result);

                $naslov = $row['naslov'];
                $sazetak = $row['sazetak'];
                $sadrzaj = $row['tekst'];
                $datum = $row['datum'];
                $slika = $row['slika'];
            }
        ?>
        <title><?php echo $naslov; ?></title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/clanak.css">
    </head>

    <body>
        <?php include 'header.php'; ?>

        <main>
            <?php
                echo "
                    <section id='naslov'>
                        <h1>$naslov</h1>
                        <h2>$sazetak</h2>
                        <p>Objavljeno: ". date("d.m.Y", strtotime($datum)) ."</p>
                    </section>
                ";
                echo "<hr>";
                echo "
                    <section id='slika'>
                        <img src='img/$slika' alt='slika'>
                    </section>
                ";
                echo "<hr>";
                echo "
                    <section id='sadrzaj'>
                        <p>$sadrzaj</p>
                    </section>
                ";
            ?>
        </main>

        <?php include 'footer.php'; ?>
    </body>
</html>